﻿
namespace rr
{
    partial class frmRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BackToLoginLbl = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.RegisterBtn = new System.Windows.Forms.Button();
            this.TxtBoxConfirmPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtBoxPassword = new System.Windows.Forms.TextBox();
            this.UserPassordLbl = new System.Windows.Forms.Label();
            this.TxtBoxUserName = new System.Windows.Forms.TextBox();
            this.userLable = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ChekBoxShowPassword = new System.Windows.Forms.CheckBox();
            this.ChekBoxAdmin = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BackToLoginLbl
            // 
            this.BackToLoginLbl.AutoSize = true;
            this.BackToLoginLbl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BackToLoginLbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.BackToLoginLbl.Location = new System.Drawing.Point(128, 583);
            this.BackToLoginLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.BackToLoginLbl.Name = "BackToLoginLbl";
            this.BackToLoginLbl.Size = new System.Drawing.Size(89, 17);
            this.BackToLoginLbl.TabIndex = 38;
            this.BackToLoginLbl.Text = "Back to login";
            this.BackToLoginLbl.Click += new System.EventHandler(this.BackToLoginLbl_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(98, 554);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 17);
            this.label3.TabIndex = 39;
            this.label3.Text = "Already Have an Account";
            // 
            // RegisterBtn
            // 
            this.RegisterBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.RegisterBtn.FlatAppearance.BorderSize = 0;
            this.RegisterBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RegisterBtn.ForeColor = System.Drawing.Color.White;
            this.RegisterBtn.Location = new System.Drawing.Point(40, 454);
            this.RegisterBtn.Margin = new System.Windows.Forms.Padding(4);
            this.RegisterBtn.Name = "RegisterBtn";
            this.RegisterBtn.Size = new System.Drawing.Size(288, 46);
            this.RegisterBtn.TabIndex = 37;
            this.RegisterBtn.Text = "Register";
            this.RegisterBtn.UseVisualStyleBackColor = false;
            this.RegisterBtn.Click += new System.EventHandler(this.RegisterBtn_Click);
            // 
            // TxtBoxConfirmPassword
            // 
            this.TxtBoxConfirmPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.TxtBoxConfirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtBoxConfirmPassword.Font = new System.Drawing.Font("Nirmala UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtBoxConfirmPassword.Location = new System.Drawing.Point(40, 356);
            this.TxtBoxConfirmPassword.Margin = new System.Windows.Forms.Padding(4);
            this.TxtBoxConfirmPassword.Multiline = true;
            this.TxtBoxConfirmPassword.Name = "TxtBoxConfirmPassword";
            this.TxtBoxConfirmPassword.Size = new System.Drawing.Size(288, 37);
            this.TxtBoxConfirmPassword.TabIndex = 36;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 330);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 17);
            this.label2.TabIndex = 35;
            this.label2.Text = "Confirm Password";
            // 
            // TxtBoxPassword
            // 
            this.TxtBoxPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.TxtBoxPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtBoxPassword.Font = new System.Drawing.Font("Nirmala UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtBoxPassword.Location = new System.Drawing.Point(40, 260);
            this.TxtBoxPassword.Margin = new System.Windows.Forms.Padding(4);
            this.TxtBoxPassword.Multiline = true;
            this.TxtBoxPassword.Name = "TxtBoxPassword";
            this.TxtBoxPassword.Size = new System.Drawing.Size(288, 37);
            this.TxtBoxPassword.TabIndex = 34;
            // 
            // UserPassordLbl
            // 
            this.UserPassordLbl.AutoSize = true;
            this.UserPassordLbl.Location = new System.Drawing.Point(40, 234);
            this.UserPassordLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.UserPassordLbl.Name = "UserPassordLbl";
            this.UserPassordLbl.Size = new System.Drawing.Size(66, 17);
            this.UserPassordLbl.TabIndex = 33;
            this.UserPassordLbl.Text = "Password";
            // 
            // TxtBoxUserName
            // 
            this.TxtBoxUserName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.TxtBoxUserName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtBoxUserName.Font = new System.Drawing.Font("Nirmala UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtBoxUserName.Location = new System.Drawing.Point(40, 169);
            this.TxtBoxUserName.Margin = new System.Windows.Forms.Padding(4);
            this.TxtBoxUserName.Multiline = true;
            this.TxtBoxUserName.Name = "TxtBoxUserName";
            this.TxtBoxUserName.Size = new System.Drawing.Size(288, 37);
            this.TxtBoxUserName.TabIndex = 32;
            // 
            // userLable
            // 
            this.userLable.AutoSize = true;
            this.userLable.Location = new System.Drawing.Point(40, 143);
            this.userLable.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.userLable.Name = "userLable";
            this.userLable.Size = new System.Drawing.Size(71, 17);
            this.userLable.TabIndex = 31;
            this.userLable.Text = "UserName";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label1.Location = new System.Drawing.Point(35, 83);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 27);
            this.label1.TabIndex = 30;
            this.label1.Text = "Get started";
            // 
            // ChekBoxShowPassword
            // 
            this.ChekBoxShowPassword.AutoSize = true;
            this.ChekBoxShowPassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChekBoxShowPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChekBoxShowPassword.Location = new System.Drawing.Point(206, 400);
            this.ChekBoxShowPassword.Name = "ChekBoxShowPassword";
            this.ChekBoxShowPassword.Size = new System.Drawing.Size(119, 21);
            this.ChekBoxShowPassword.TabIndex = 40;
            this.ChekBoxShowPassword.Text = "Show Password";
            this.ChekBoxShowPassword.UseVisualStyleBackColor = true;
            // 
            // ChekBoxAdmin
            // 
            this.ChekBoxAdmin.AutoSize = true;
            this.ChekBoxAdmin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChekBoxAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChekBoxAdmin.Location = new System.Drawing.Point(40, 400);
            this.ChekBoxAdmin.Name = "ChekBoxAdmin";
            this.ChekBoxAdmin.Size = new System.Drawing.Size(65, 21);
            this.ChekBoxAdmin.TabIndex = 40;
            this.ChekBoxAdmin.Text = "Admin";
            this.ChekBoxAdmin.UseVisualStyleBackColor = true;
            this.ChekBoxAdmin.CheckedChanged += new System.EventHandler(this.ChekBoxAdmin_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = global::rr.Properties.Resources.exit;
            this.pictureBox1.Location = new System.Drawing.Point(315, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 28);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // frmRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 660);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ChekBoxAdmin);
            this.Controls.Add(this.ChekBoxShowPassword);
            this.Controls.Add(this.BackToLoginLbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.RegisterBtn);
            this.Controls.Add(this.TxtBoxConfirmPassword);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TxtBoxPassword);
            this.Controls.Add(this.UserPassordLbl);
            this.Controls.Add(this.TxtBoxUserName);
            this.Controls.Add(this.userLable);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(165)))), ((int)(((byte)(169)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmRegister";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmRegister_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label BackToLoginLbl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button RegisterBtn;
        private System.Windows.Forms.TextBox TxtBoxConfirmPassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtBoxPassword;
        private System.Windows.Forms.Label UserPassordLbl;
        private System.Windows.Forms.TextBox TxtBoxUserName;
        private System.Windows.Forms.Label userLable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox ChekBoxShowPassword;
        private System.Windows.Forms.CheckBox ChekBoxAdmin;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

