﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rr
{
    public class Customer
    {
        public string Cost_Name { get; set; }
        public string Cost_Adress { get; set; }
    }
}
